/*
 * Hunter class inherits constructor from superclass
 * Characters
 * 
 */
public class Hunter extends Character {
	
	int gold;
	int MAXHEALTH;
	int CURRHEALTH;
	private float PercentH;
	
	public Hunter(int level, int exp, String gender, String Name, int defense, int health, int strength, int g, int maxH, int currH) {
		super(level, exp, gender, Name, defense, health, strength);
		gold=g;
		MAXHEALTH=maxH;
		CURRHEALTH=currH;
	}
	
	
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}


	public int getMAXHEALTH() {
		return MAXHEALTH;
	}


	public void setMAXHEALTH(int mAXHEALTH) {
		MAXHEALTH = mAXHEALTH;
	}


	public int getCURRHEALTH() {
		return CURRHEALTH;
	}


	public void setCURRHEALTH(int cURRHEALTH) {
		CURRHEALTH = cURRHEALTH;
	}
	public float percH()
	{
		PercentH=CURRHEALTH/MAXHEALTH;
		return PercentH;
		
	}
}