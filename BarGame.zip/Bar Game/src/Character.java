
public class Character {

	String Name;
	int level;
	int exp;
	String gender;
	int defense;
	int health;
	int strength;
	public Character(int level, int exp, String gender,String Name,int defense, int health, int strength )
	{
		this.gender=gender;
		this.level=level;
		this.exp=exp;
		this.Name=Name;
		this.strength=strength;
		this.health=health;
		this.defense=defense;
	}

	
	public int getDefense() {
		return defense;
	}


	public void setDefense(int defense) {
		this.defense = defense;
	}


	public int getHealth() {
		return health;
	}


	public void setHealth(int health) {
		this.health = health;
	}


	public int getStrength() {
		return strength;
	}


	public void setStrength(int strength) {
		this.strength = strength;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	
	public String toString() {
		return("Name: "+Name+"\nGender: "+gender+"\nExperience: "+exp+"\nLevel: "+level);
	}
	
	
}
